import 'package:flutter/material.dart';
import 'style_const.dart';
import 'home_page.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'PET宠物健康',
      debugShowCheckedModeBanner: false,
      scaffoldBackgroundColor: AppColors.background,
      theme: ThemeData(
        primaryColor: AppColors.primary,
        appBarTheme: AppBarTheme(backgroundColor: AppColors.primary),
      ),
      home: const HomePage(),
    );
  }
}
