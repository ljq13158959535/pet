import 'package:flutter/material.dart';
import 'style_const.dart';

class TestCollectPage extends StatefulWidget {
  const TestCollectPage({super.key});

  @override
  State<TestCollectPage> createState() => _TestCollectPageState();
}

class _TestCollectPageState extends State<TestCollectPage> {
  final List<String> scenes = [
    "安静站立", "慢走", "快走", "慢跑", "快跑",
    "上下楼梯", "跳跃", "躺卧", "进食", "饮水",
    "抖动", "摇头", "坐下", "趴下", "翻身"
  ];

  int? selectedIndex;
  String status = "请选择测试场景";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: Text("15场景实测标定"), backgroundColor: AppColors.primary, elevation: 0),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(AppSpace.p14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: double.infinity,
              padding: EdgeInsets.all(AppSpace.p12),
              decoration: BoxDecoration(
                color: AppColors.info.withOpacity(0.1),
                borderRadius: BorderRadius.circular(AppRadius.normal),
              ),
              child: Row(
                children: [
                  Icon(Icons.info_outline, color: AppColors.info, size: 18),
                  SizedBox(width: AppSpace.p8),
                  Expanded(child: Text(status, style: AppFont.bodySmall)),
                ],
              ),
            ),
            SizedBox(height: AppSpace.p16),
            Text("选择场景开始采集", style: AppFont.subTitle),
            SizedBox(height: AppSpace.p10),
            ...List.generate((scenes.length + 2) ~/ 3, (row) {
              return Padding(
                padding: EdgeInsets.only(bottom: AppSpace.p8),
                child: Row(
                  children: List.generate(3, (col) {
                    int idx = row * 3 + col;
                    if (idx >= scenes.length) return const Expanded(child: SizedBox());
                    return Expanded(
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: AppSpace.p4),
                        child: GestureDetector(
                          onTap: () {
                            setState(() {
                              selectedIndex = idx;
                              status = "正在采集：${scenes[idx]}";
                            });
                          },
                          child: Container(
                            padding: EdgeInsets.symmetric(vertical: AppSpace.p14),
                            decoration: BoxDecoration(
                              color: selectedIndex == idx ? AppColors.primary : AppColors.card,
                              borderRadius: BorderRadius.circular(AppRadius.normal),
                              border: Border.all(
                                color: selectedIndex == idx ? AppColors.primary : AppColors.border,
                              ),
                            ),
                            child: Center(
                              child: Text(
                                scenes[idx],
                                style: TextStyle(
                                  fontSize: 13,
                                  color: selectedIndex == idx ? Colors.white : AppColors.textMain,
                                  fontWeight: selectedIndex == idx ? FontWeight.w500 : FontWeight.normal,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    );
                  }),
                ),
              );
            }),
            SizedBox(height: AppSpace.p16),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: AppStyle.primaryButton,
                onPressed: selectedIndex != null ? () {} : null,
                child: Text(selectedIndex != null ? "开始采集数据" : "请先选择场景"),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
