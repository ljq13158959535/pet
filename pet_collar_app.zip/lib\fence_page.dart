import 'package:flutter/material.dart';
import 'style_const.dart';

class FencePage extends StatelessWidget {
  const FencePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: Text("电子围栏"), backgroundColor: AppColors.primary, elevation: 0),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(AppSpace.p14),
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.all(AppSpace.p16),
              decoration: AppStyle.cardStyle,
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text("启用围栏", style: AppFont.body),
                      Switch(value: true, onChanged: (v) {}, activeColor: AppColors.primary),
                    ],
                  ),
                  Divider(height: 24, color: AppColors.border),
                  _buildInput("中心点经度"),
                  SizedBox(height: AppSpace.p12),
                  _buildInput("中心点纬度"),
                  SizedBox(height: AppSpace.p12),
                  _buildInput("安全半径（米）"),
                ],
              ),
            ),
            SizedBox(height: AppSpace.p16),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: AppStyle.primaryButton,
                onPressed: () {},
                child: Text("保存并下发"),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInput(String label) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: AppFont.bodySmall),
        SizedBox(height: AppSpace.p6),
        TextField(decoration: AppStyle.textFieldStyle),
      ],
    );
  }
}
