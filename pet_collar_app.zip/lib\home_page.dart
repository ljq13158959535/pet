import 'package:flutter/material.dart';
import 'style_const.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _currentIndex = 0;

  final List<Widget> _pages = [
    const HomeContent(),
    const FencePage(),
    const AlarmPage(),
    const HistoryPage(),
    const TestCollectPage(),
  ];

  void onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: _pages[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        selectedItemColor: AppColors.primary,
        unselectedItemColor: AppColors.textSub,
        backgroundColor: Colors.white,
        type: BottomNavigationBarType.fixed,
        onTap: onTabTapped,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "首页"),
          BottomNavigationBarItem(icon: Icon(Icons.map), label: "围栏"),
          BottomNavigationBarItem(icon: Icon(Icons.warning), label: "告警"),
          BottomNavigationBarItem(icon: Icon(Icons.history), label: "历史"),
          BottomNavigationBarItem(icon: Icon(Icons.build), label: "实测"),
        ],
      ),
    );
  }
}

class HomeContent extends StatelessWidget {
  const HomeContent({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: EdgeInsets.all(AppSpace.p14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(height: AppSpace.p16),
          Text("PET 宠物智能项圈", style: AppFont.title),
          SizedBox(height: AppSpace.p12),
          Container(
            padding: EdgeInsets.all(AppSpace.p16),
            decoration: AppStyle.cardStyle,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("设备状态", style: AppFont.bodySmall),
                    SizedBox(height: AppSpace.p4),
                    Text("已连接", style: TextStyle(color: AppColors.success, fontSize: 15, fontWeight: FontWeight.w500)),
                  ],
                ),
                ElevatedButton(
                  style: AppStyle.primaryButton,
                  onPressed: () {},
                  child: Text("重新连接"),
                ),
              ],
            ),
          ),
          SizedBox(height: AppSpace.p20),
          Text("实时健康数据", style: AppFont.subTitle),
          SizedBox(height: AppSpace.p10),
          Row(
            children: [
              _buildCard("心率", "78", "次/分", Icons.favorite),
              SizedBox(width: AppSpace.p8),
              _buildCard("体温", "37.2", "℃", Icons.thermostat),
              SizedBox(width: AppSpace.p8),
              _buildCard("活动", "124", "", Icons.directions_run),
            ],
          ),
          SizedBox(height: AppSpace.p20),
          Text("位置与安全", style: AppFont.subTitle),
          SizedBox(height: AppSpace.p10),
          Container(
            padding: EdgeInsets.all(AppSpace.p14),
            decoration: AppStyle.cardStyle,
            child: Row(
              children: [
                Icon(Icons.check_circle, color: AppColors.success),
                SizedBox(width: AppSpace.p8),
                Text("在安全围栏内", style: AppFont.body),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCard(String title, String value, String unit, IconData icon) {
    return Expanded(
      child: Container(
        padding: EdgeInsets.all(AppSpace.p14),
        decoration: AppStyle.cardStyle,
        child: Column(
          children: [
            Icon(icon, color: AppColors.primary, size: 24),
            SizedBox(height: AppSpace.p8),
            Text(title, style: AppFont.bodySmall),
            SizedBox(height: AppSpace.p4),
            Text(value, style: AppFont.number),
            if (unit.isNotEmpty) Text(unit, style: AppFont.tip),
          ],
        ),
      ),
    );
  }
}
