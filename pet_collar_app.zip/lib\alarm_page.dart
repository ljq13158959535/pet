import 'package:flutter/material.dart';
import 'style_const.dart';

class AlarmPage extends StatelessWidget {
  const AlarmPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: Text("告警记录"), backgroundColor: AppColors.primary, elevation: 0),
      body: ListView(
        padding: EdgeInsets.all(AppSpace.p14),
        children: [
          _alarmItem("越界告警", "10:23", "宠物离开安全区域"),
          _alarmItem("体温异常", "昨天 18:12", "体温 39.5℃，偏高"),
          _alarmItem("心率异常", "昨天 15:40", "心率持续过高"),
        ],
      ),
    );
  }

  Widget _alarmItem(String title, String time, String desc) {
    return Container(
      margin: EdgeInsets.only(bottom: AppSpace.p10),
      padding: EdgeInsets.all(AppSpace.p14),
      decoration: AppStyle.cardStyle,
      child: Row(
        children: [
          Icon(Icons.warning_amber, color: AppColors.error),
          SizedBox(width: AppSpace.p10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: AppFont.body),
              SizedBox(height: AppSpace.p4),
              Text(desc, style: AppFont.tip),
            ],
          ),
          Spacer(),
          Text(time, style: AppFont.tip),
        ],
      ),
    );
  }
}
