class BleService {
  static double heart = 75;
  static double temp = 37.2;
  static int shake = 120;
  static bool isInSafe = true;
  static double gpsLat = 19.99;
  static double gpsLon = 110.35;

  static bool fenceEnable = true;
  static double fenceLat = 19.99;
  static double fenceLon = 110.35;
  static double fenceR = 100;

  static Stream<bool> get bleConnectStream => Stream.value(true);

  static void startScanConnect() {}

  static void sendFenceCfg() {}

  static void saveSceneThreshold(Map<dynamic, dynamic> thCtrl) {}
}
