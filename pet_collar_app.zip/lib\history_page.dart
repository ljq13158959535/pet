import 'package:flutter/material.dart';
import 'style_const.dart';

class HistoryPage extends StatelessWidget {
  const HistoryPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: Text("历史数据"), backgroundColor: AppColors.primary, elevation: 0),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(AppSpace.p14),
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.all(AppSpace.p16),
              decoration: AppStyle.cardStyle,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("今日统计", style: AppFont.subTitle),
                  SizedBox(height: AppSpace.p12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _statItem("平均心率", "76"),
                      _statItem("平均体温", "37.1"),
                      _statItem("活动量", "8600"),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _statItem(String label, String value) {
    return Column(
      children: [
        Text(value, style: AppFont.number),
        SizedBox(height: AppSpace.p4),
        Text(label, style: AppFont.tip),
      ],
    );
  }
}
