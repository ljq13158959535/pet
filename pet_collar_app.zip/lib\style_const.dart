import 'package:flutter/material.dart';

class AppColors {
  static const Color primary = Color(0xFF26B99A);
  static const Color background = Color(0xFFF7F8FA);
  static const Color card = Colors.white;
  static const Color border = Color(0xFFE5E7EB);
  static const Color textMain = Color(0xFF1D2129);
  static const Color textSub = Color(0xFF86909C);
  static const Color textTip = Color(0xFFC9CDD4);
  static const Color success = Color(0xFF26B99A);
  static const Color warning = Color(0xFFFF9500);
  static const Color error = Color(0xFFF53F3F);
  static const Color info = Color(0xFF508BED);
}

class AppRadius {
  static const double small = 6.0;
  static const double normal = 8.0;
  static const double card = 12.0;
  static const double button = 10.0;
}

class AppSpace {
  static const double p4 = 4.0;
  static const double p6 = 6.0;
  static const double p8 = 8.0;
  static const double p10 = 10.0;
  static const double p12 = 12.0;
  static const double p14 = 14.0;
  static const double p16 = 16.0;
}

class AppFont {
  static const TextStyle title = TextStyle(fontSize:18,fontWeight:FontWeight.w600,color:AppColors.textMain);
  static const TextStyle subTitle = TextStyle(fontSize:16,fontWeight:FontWeight.w500,color:AppColors.textMain);
  static const TextStyle body = TextStyle(fontSize:15,color:AppColors.textMain);
  static const TextStyle bodySmall = TextStyle(fontSize:14,color:AppColors.textSub);
  static const TextStyle tip = TextStyle(fontSize:12,color:AppColors.textSub);
  static const TextStyle mini = TextStyle(fontSize:11,color:AppColors.textSub);
  static const TextStyle number = TextStyle(fontSize:15,fontWeight:FontWeight.w600,color:AppColors.textMain);
}

class AppStyle {
  static BoxDecoration cardStyle = BoxDecoration(
    color: AppColors.card,
    borderRadius: BorderRadius.circular(AppRadius.card),
    border: Border.all(color: AppColors.border,width:0.3),
    boxShadow: [BoxShadow(color:Colors.black12.withOpacity(0.03),blurRadius:3,offset:Offset(0,1))]
  );
  static ButtonStyle primaryButton = ElevatedButton.styleFrom(
    backgroundColor: AppColors.primary,elevation:0,
    shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(AppRadius.button)),
    padding:EdgeInsets.symmetric(vertical:12)
  );
  static ButtonStyle outlineButton = OutlinedButton.styleFrom(
    side:BorderSide(color:AppColors.border),
    shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(AppRadius.button)),
    padding:EdgeInsets.symmetric(vertical:12)
  );
  static InputDecoration textFieldStyle = InputDecoration(
    filled:true,fillColor:AppColors.card,
    contentPadding:EdgeInsets.symmetric(horizontal:12,vertical:12),
    border:OutlineInputBorder(borderRadius:BorderRadius.circular(AppRadius.normal),borderSide:BorderSide(color:AppColors.border)),
    enabledBorder:OutlineInputBorder(borderRadius:BorderRadius.circular(AppRadius.normal),borderSide:BorderSide(color:AppColors.border)),
    focusedBorder:OutlineInputBorder(borderRadius:BorderRadius.circular(AppRadius.normal),borderSide:BorderSide(color:AppColors.primary,width:1.5)),
    hintStyle:AppFont.tip
  );
}

class AppTips {
  static const String deviceOffline = "设备离线，请点击搜索配对";
  static const String deviceConnected = "设备已连接";
  static const String fenceInside = "处于安全围栏内";
  static const String fenceOutside = "宠物已离开安全围栏范围，请注意查看位置";
  static const String saveSuccess = "参数已同步至项圈设备";
  static const String noData = "暂无数据，开始采样后自动生成记录";
  static const String pleaseSelectScene = "请先选择测试场景";
}
