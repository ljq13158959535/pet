import 'package:flutter/material.dart';
import 'style_const.dart';
import 'home_page.dart';
import 'fence_page.dart';
import 'alarm_page.dart';
import 'history_page.dart';
import 'TestCollectPage.dart';

// 导出所有页面，方便 main.dart 直接使用
export 'style_const.dart';
export 'home_page.dart';
export 'fence_page.dart';
export 'alarm_page.dart';
export 'history_page.dart';
export 'TestCollectPage.dart';
